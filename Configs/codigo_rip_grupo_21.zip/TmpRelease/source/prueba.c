#include "rip.h"

int main()
{
  return 0; 
}