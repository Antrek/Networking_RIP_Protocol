clear;clear;clear;
set +v
echo "========== Compilando eth_client =========="
cd source/;
rawnetcc eth_client eth_client.c eth.c
mv eth_client ../bins/eth_client
cd ..
